package com.way2learnonline.utils;

import java.util.HashMap;
import java.util.Map;

public class CacheUtil {
	
	public static Map<String, Object> cache=new HashMap<String, Object>();

}
