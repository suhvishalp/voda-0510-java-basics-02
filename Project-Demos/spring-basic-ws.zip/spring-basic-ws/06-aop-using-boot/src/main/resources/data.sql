           
insert into customers(customerid,name,city,country) values(1,'shiva','Bangalore','India');
insert into customers(customerid,name,city,country) values(2,'Prasad','Bangalore','India');
insert into customers(customerid,name,city,country) values(3,'Rishik','Bangalore','India');


	insert into account(name,isactive,city,country,balance,emailaddress) values('shiva',true,'Bangalore','India',10000,'sivaprasad.valluru@gmail.com');
	insert into account(name,isactive,city,country,balance,emailaddress) values('Prasad',true,'Hyderabad','India',20000,'siva@gmail.com');
