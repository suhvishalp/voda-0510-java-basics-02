package com.way2learnonline.model;

public class NumberGuess {
	
	private double randomNumber;

	public double getRandomNumber() {
		return randomNumber;
	}

	public void setRandomNumber(double randomNumber) {
		this.randomNumber = randomNumber;
	}
	
	

}
